import * as Sentry from "@sentry/browser";
import {initialize} from "./core.mjs";
export const initBrowser = config => initialize(Sentry,{...config,runtime:"browser"});
