import type {Reporter} from "./index.js";
export function wrapHttpHandler<T extends (...args:any[])=>any>(handler:T, reporter:Reporter):T;
