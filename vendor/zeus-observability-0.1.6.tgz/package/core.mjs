// Never add raw messages, URLs, users, requests, breadcrumbs or arbitrary context here.
const TYPES = new Set(["Error","TypeError","RangeError","ReferenceError","SyntaxError","URIError","EvalError","AggregateError","DOMException","AbortError","TimeoutError","NetworkError","NotAllowedError","NotFoundError","SecurityError","ApplicationError"]);
const OPERATIONS = new Set(["application","photo","voice","upload","auth","billing","checkout","save","load","worker","api","canary"]);
const STAGES = new Set(["runtime","start","permission","prepare","capture","connect","upload","transcribe","parse","review","apply","save","request","render","job","complete"]);
const OUTCOMES = new Set(["success","failure","cancelled"]);
const REASONS = new Set(["unexpected","network","timeout","permission-denied","unsupported","invalid-input","provider","server","client","canary"]);
const HEX32 = /^[a-f0-9]{32}$/i, HEX16 = /^[a-f0-9]{16}$/i;
const UUID = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
const pick = (value, allowed, fallback) => allowed.has(value) ? value : fallback;
function boundedNumber(value, max) {
  return typeof value === "number" && Number.isFinite(value) && value >= 0 ? Math.min(value,max) : undefined;
}
function codeFile(value) {
  if (typeof value !== "string") return undefined;
  if (/^file:\/\/[^/]/i.test(value)) value=value.replace(/\\/g,"/").split(/[?#]/,1)[0].split("/").pop();
  const clean = value.replace(/\\/g,"/").replace(/^file:\/\//, "").split(/[?#]/,1)[0].replace(/^\/?[A-Za-z]:\//,"/").slice(0,500);
  if (!/\.(?:[cm]?js|jsx|ts|tsx|py|html|bundle)$/.test(clean) && !/^https?:\/\/[^/]+\/$/.test(clean)) return undefined;
  if (/^https?:\/\//.test(clean)) {
    try {
      const url=new URL(clean);
      if ((/^\/(?:_next\/static|_expo\/static|assets|static)\//.test(url.pathname) || url.pathname === "/" || url.pathname === "/index.html")) return url.origin+url.pathname;
      return url.pathname.split("/").pop();
    } catch { return undefined; }
  }
  if (clean.startsWith("//")) return clean.split("/").pop();
  return clean.replace(/^.*?(?=\/(?:src|app|node_modules|\.next)\/)/,"")
    .replace(/^.*?\/(?:home|Users|Documents and Settings)\/[^/]+\//i,"/");
}
function frame(value) {
  const result={};
  const file=codeFile(value?.filename ?? value?.abs_path);
  if (file) result.filename=file;
  if (typeof value?.function==="string" && /^[A-Za-z0-9_.$<>\[\] /:-]{1,160}$/.test(value.function)) result.function=value.function;
  for (const key of ["lineno","colno"]) {
    const number=boundedNumber(value?.[key],10000000);
    if (number!==undefined) result[key]=Math.floor(number);
  }
  if (typeof value?.in_app==="boolean") result.in_app=value.in_app;
  return result;
}
function trace(value) {
  if (!value || !HEX32.test(value.trace_id) || !HEX16.test(value.span_id)) return undefined;
  return {trace_id:value.trace_id,span_id:value.span_id,...(HEX16.test(value.parent_span_id)?{parent_span_id:value.parent_span_id}:{})};
}
export function configFor(config={}) {
  const product=/^[a-z][a-z0-9-]{0,63}$/.test(config.product) ? config.product : "unknown";
  const environment=pick(config.environment,new Set(["production","preview","development","test"]),"development");
  const release=typeof config.release==="string" && /^[a-z0-9@._-]{1,160}$/i.test(config.release) ? config.release : undefined;
  let dsn;
  try {
    const url=new URL(config.dsn);
    if (((url.protocol==="https:" && url.hostname==="zeus.tailfad2e3.ts.net" && url.port==="8443") ||
        (url.protocol==="http:" && url.hostname==="127.0.0.1" && ["8890","8816"].includes(url.port))) &&
        /^[a-f0-9]{32}$/i.test(url.username) && /^\/[1-9][0-9]*$/.test(url.pathname) && !url.password && !url.search && !url.hash) dsn=url.href;
  } catch { /* Missing or invalid configuration disables reporting. */ }
  const target=/^[a-z][a-z0-9-]{0,63}$/.test(config.target) ? config.target : undefined;
  const deploymentId=typeof config.deploymentId==="string" && /^[a-f0-9]{64}$/.test(config.deploymentId) ? config.deploymentId : undefined;
  return {product,environment,release,dsn,target,deploymentId,runtime:pick(config.runtime,new Set(["browser","node","edge","python","native"]),"browser")};
}
function safeTags(tags={}, config) {
  const result={"zeus.product":config.product,"zeus.runtime":config.runtime,"zeus.adapter":"0.1.6"};
  result["zeus.target"]=config.target || config.runtime;
  for (const [key,allowed] of [["operation",OPERATIONS],["stage",STAGES],["outcome",OUTCOMES],["reason",REASONS]]) {
    if (allowed.has(tags[key])) result[key]=tags[key];
  }
  if (UUID.test(tags.correlation_id)) result.correlation_id=tags.correlation_id;
  if (tags.synthetic==="true") {
    result.synthetic="true";
    if (config.deploymentId) result["zeus.deployment"]=config.deploymentId;
  }
  return result;
}
export function sanitizeEvent(event, rawConfig) {
  const config=configFor(rawConfig);
  if (!event || event.type) return null; // Transactions have a separate opt-in contract.
  const tags=safeTags(event.tags,config);
  const values=(event.exception?.values || []).slice(0,5).map(value=>{
    const type=pick(value.type,TYPES,"ApplicationError");
    const safe={type,value:type+" ("+(tags.operation||"application")+":"+(tags.stage||"runtime")+":"+(tags.reason||"unexpected")+")"};
    if (value.stacktrace?.frames) safe.stacktrace={frames:value.stacktrace.frames.slice(-50).map(frame)};
    if (typeof value.mechanism?.handled==="boolean") safe.mechanism={type:"generic",handled:value.mechanism.handled};
    return safe;
  });
  const result={platform:config.runtime==="python"?"python":"javascript",level:event.level==="fatal"?"fatal":"error",environment:config.environment,tags};
  if (tags.synthetic === "true") result.fingerprint=["zeus-canary",config.product,config.runtime,config.target || config.runtime,config.release || "unreleased"];
  if (config.release) result.release=config.release;
  if (HEX32.test(event.event_id)) result.event_id=event.event_id;
  const timestamp=boundedNumber(event.timestamp,100000000000);
  if (timestamp!==undefined) result.timestamp=timestamp;
  if (values.length) result.exception={values}; else result.message="Application failure";
  const context=trace(event.contexts?.trace);
  if (context) result.contexts={trace:context};
  const images=event.debug_meta?.images?.slice(0,50).flatMap(value=>{
    const file=codeFile(value.code_file);
    return value.type==="sourcemap" && UUID.test(value.debug_id) && file ? [{type:"sourcemap",debug_id:value.debug_id,code_file:file}] : [];
  });
  if (images?.length) result.debug_meta={images};
  return result;
}
export function sanitizeLog(log, rawConfig) {
  if (log?.message!=="zeus.workflow") return null;
  const config=configFor(rawConfig), input=log.attributes || {};
  if (!OPERATIONS.has(input.operation) || !STAGES.has(input.stage) || !OUTCOMES.has(input.outcome)) return null;
  const attributes={...safeTags(input,config),"sentry.environment":config.environment};
  if (config.release) attributes["sentry.release"]=config.release;
  const duration=boundedNumber(input.duration_ms,86400000);
  if (duration!==undefined) attributes.duration_ms=Math.round(duration);
  return {level:"info",message:"zeus.workflow",attributes};
}
export function sdkOptions(rawConfig) {
  const config=configFor(rawConfig);
  return {
    dsn:config.dsn,enabled:Boolean(config.dsn),environment:config.environment,release:config.release,
    sendDefaultPii:false,sendClientReports:true,sampleRate:1,enableLogs:true,maxBreadcrumbs:0,
    autoSessionTracking:false,maxValueLength:400,
    transportOptions:{bufferSize:30},
    dataCollection:{
      userInfo:false,cookies:false,httpHeaders:{request:false,response:false},httpBodies:[],
      urlQueryParams:false,graphQL:{document:false,variables:false},genAI:{inputs:false,outputs:false},
      databaseQueryData:false,stackFrameVariables:false,frameContextLines:0,
    },
    integrations:defaults=>defaults.filter(item=>!/(Breadcrumbs|HttpContext|ContextLines|LocalVariables|Console|Replay|Profil|Session|OpenAI|Anthropic|LangChain|VercelAI|GoogleGenAI)/i.test(item.name)),
    beforeBreadcrumb:()=>null,
    beforeSend:event=>sanitizeEvent(event,config),
    beforeSendTransaction:()=>null,
    beforeSendLog:log=>sanitizeLog(log,config),
  };
}
export function createReporter(sdk, rawConfig) {
  const config=configFor(rawConfig);
  const failure=(error, metadata={})=>{
    if (!config.dsn) return undefined;
    try {
      let eventId;
      sdk.withScope(scope=>{
        scope.setTags(safeTags(metadata,config));
        eventId=sdk.captureException(error instanceof Error?error:new Error("Application failure"));
      });
      return eventId;
    } catch { return undefined; }
  };
  return Object.freeze({
    enabled:Boolean(config.dsn),
    failure,
    workflow(operation, stage) {
      const started=globalThis.performance?.now?.() ?? Date.now();
      const correlation=globalThis.crypto?.randomUUID?.();
      let finished=false;
      return Object.freeze({
        correlationId:correlation,
        finish(outcome, reason="unexpected", error) {
          if (finished) return;
          finished=true;
          if (!config.dsn || !OPERATIONS.has(operation) || !STAGES.has(stage) || !OUTCOMES.has(outcome)) return;
          const metadata={operation,stage,outcome,reason:pick(reason,REASONS,"unexpected"),...(correlation?{correlation_id:correlation}:{}),
            duration_ms:Math.max(0,(globalThis.performance?.now?.() ?? Date.now())-started)};
          try { sdk.logger?.info("zeus.workflow",metadata); } catch { /* Telemetry must not affect a workflow. */ }
          if (outcome==="failure") failure(error ?? new Error("Workflow failure"),metadata);
        },
      });
    },
  });
}
export function initialize(sdk, config) {
  try {
    const options=sdkOptions(config);
    if (options.enabled) sdk.init(options);
    return createReporter(sdk,config);
  } catch { return createReporter({}, {...config,dsn:undefined}); }
}
