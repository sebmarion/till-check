# Zeus observability adapter

Pinned Sentry SDKs send to self-hosted GlitchTip. No Sentry Cloud account is required.

Initialize before application code. Set a per-product, per-environment DSN and the exact built release revision. A missing DSN disables reporting; it must be shown as unconfigured in Zeus, never healthy.

The adapter allows stack locations, static failure categories, bounded timings and random correlation IDs. It drops raw error messages, customer identities, request/response bodies, URL queries, cookies, breadcrumbs, local variables, console logs, replay, profiles and AI payloads. Do not pass business identifiers as release names.

`reporter.workflow("photo","upload").finish("success")` records a bounded outcome log. Call finish exactly once; cancel uses `cancelled`. A failure records both an outcome and an exception. Outcome logs are unsampled; collector limits and delivery gaps must be included when interpreting denominators.

Error collection is independent of performance tracing. Automatic traces are disabled until a runtime-specific privacy and source-map check passes. This package does not silently install global Python or Node hooks.

SDK queues are bounded; reporting must never be awaited on the customer path. Collector outages do not change application behavior. Flush explicitly only in job shutdown hooks and test/canary commands.
