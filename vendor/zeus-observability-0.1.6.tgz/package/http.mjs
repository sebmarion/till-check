// Observe HTTP completion without retaining request or response data.
export function wrapHttpHandler(handler, reporter) {
  return async function zeusObservedHandler(request, response) {
    let outcome;
    const workflow = reporter.workflow("api", "request");
    const finish = (value, reason, error) => {
      if (outcome) return;
      outcome = value;
      workflow.finish(value, reason, error);
    };
    response.once?.("finish", () => finish(
      response.statusCode >= 500 ? "failure" : response.statusCode >= 400 ? "cancelled" : "success",
      response.statusCode >= 500 ? "server" : "client"));
    response.once?.("close", () => {
      if (!response.writableFinished) finish("cancelled", "client");
    });
    try { return await handler.call(this, request, response); }
    catch (error) {
      if (!outcome) finish("failure", "server", error);
      else reporter.failure(error, {operation:"api", stage:"request", reason:"server"});
      throw error;
    }
  };
}
