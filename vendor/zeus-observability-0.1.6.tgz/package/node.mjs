import * as Sentry from "@sentry/node";
import {initialize} from "./core.mjs";
export const initNode = config => initialize(Sentry,{target:process.env.ZEUS_TARGET,...config,runtime:"node"});
